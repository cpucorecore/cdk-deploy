module.exports = {
  skipFiles: ['mocks', 'interfaces']
};